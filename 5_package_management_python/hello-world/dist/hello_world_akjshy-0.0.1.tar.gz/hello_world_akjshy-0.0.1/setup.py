from setuptools import setup, find_packages # type: ignore

setup(
    name='hello_world-akjshy',
    version='0.0.1',
    author='Nachiketh',
    author_email='nachiketh@manifoldailearning.in',
    url='https://www.manifoldailearning.in',
    description='A hello-world example package',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ]
)